using System;
using System.Threading;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;

namespace Proxying
{
	public static class ProxyActivator
	{
		private readonly static Dictionary<string, ModuleBuilder> moduleCache = new Dictionary<string, ModuleBuilder>();

		private static int typeCount;

		public static TInterface CreateInstance<TInterface>(object handler)
		{
			return (TInterface)CreateInstance(handler, typeof(TInterface));
		}

		public static object CreateInstance(object handler, params Type[] interfaces)
		{
			if(interfaces == null)
				throw new ArgumentNullException("interfaces");

			if(handler == null)
				throw new ArgumentNullException("handler");

			if(interfaces.Length == 0)
				throw new ArgumentException("Interface array is empty.");

			Type handlerType = handler.GetType();	

			MethodInfo handlerMethod = handlerType.GetMethod("Invoke", BindingFlags.Instance | BindingFlags.Public,  new Type[]{ typeof(MethodBase), typeof(object[]) });
			if(handlerMethod == null || handlerMethod.ReturnType != typeof(object))
				throw new ArgumentException("Invalid handler type.");			

			AssemblyName caller = Assembly.GetCallingAssembly().GetName();
			ModuleBuilder moduleBuilder;
			lock(moduleCache)
			{
				if(!moduleCache.TryGetValue(caller.ToString(), out moduleBuilder))
				{
					AssemblyName assemblyName = new AssemblyName();
					assemblyName.Name = caller.Name + ".Proxies-" + Guid.NewGuid();

					AssemblyBuilder assemblyBuilder = 
						AssemblyBuilder.DefineDynamicAssembly(
						assemblyName, 
						AssemblyBuilderAccess.Run);
					assemblyBuilder.SetCustomAttribute(new CustomAttributeBuilder(
						typeof(System.Runtime.CompilerServices.IgnoresAccessChecksToAttribute).GetConstructor(new Type[]{typeof(String)}), 
						new object[]{caller.Name}));

					moduleBuilder = assemblyBuilder.DefineDynamicModule(assemblyName.Name);
					moduleCache.Add(caller.ToString(), moduleBuilder);
				}
			}

			TypeBuilder typeBuilder = moduleBuilder.DefineType(
				string.Format("<{0}>Proxy__{1}", interfaces[0].Name, Interlocked.Increment(ref typeCount)), 
				TypeAttributes.Public|TypeAttributes.Class, null, interfaces);

			FieldBuilder handlerField = GenerateField(typeBuilder, handlerType);
			ConstructorBuilder constr = GenerateConstructor(typeBuilder, handlerField);

			GenerateInterfaceImplementation(typeBuilder, interfaces, handlerField);

			Type generatedType = typeBuilder.CreateType();

			return Activator.CreateInstance(generatedType, new object[]{handler});
		}

		private static void GenerateInterfaceImplementation(TypeBuilder typeBuilder, 
			Type[] interfaces, FieldBuilder handlerField)
		{
			foreach(Type inter in interfaces)
				GenerateInterfaceImplementation(typeBuilder, inter, handlerField);
		}

		private static void GenerateInterfaceImplementation(TypeBuilder typeBuilder, 
			Type inter, FieldBuilder handlerField)
		{
			if(!inter.IsInterface)
				throw new ArgumentException("Type array expects interfaces only.");

			Type[] baseInterfaces = inter.GetInterfaces();

			GenerateInterfaceImplementation(typeBuilder, baseInterfaces, handlerField);

			PropertyInfo[] properties = inter.GetProperties();
			PropertyBuilder[] propertiesBuilder = new PropertyBuilder[properties.Length];

			for(int i=0; i < properties.Length; i++)
				GeneratePropertyImplementation(typeBuilder, properties[i], ref propertiesBuilder[i]);

			MethodInfo[] methods = inter.GetMethods();

			foreach(MethodInfo method in methods)
				GenerateMethodImplementation(typeBuilder, method, 
					propertiesBuilder, handlerField, inter);
		}

		private static FieldBuilder GenerateField(TypeBuilder typeBuilder, Type handlerType)
		{
			return typeBuilder.DefineField("handler", 
				handlerType, FieldAttributes.Public);
		}

		private static ConstructorBuilder GenerateConstructor(
			TypeBuilder typeBuilder, FieldBuilder handlerField)
		{
			ConstructorBuilder consBuilder = typeBuilder.DefineConstructor(
				MethodAttributes.Public, 
				CallingConventions.Standard, 
				new Type[] { handlerField.FieldType });
			
			ILGenerator ilGenerator = consBuilder.GetILGenerator();
			ilGenerator.Emit(OpCodes.Ldarg_0);
			ilGenerator.Emit(OpCodes.Call, typeof(Object).GetConstructor(new Type[0]));
			ilGenerator.Emit(OpCodes.Ldarg_0);
			ilGenerator.Emit(OpCodes.Ldarg_1);
			ilGenerator.Emit(OpCodes.Stfld, handlerField);
			ilGenerator.Emit(OpCodes.Ret);

			return consBuilder;
		}

		private static void GeneratePropertyImplementation(
			TypeBuilder typeBuilder, PropertyInfo property, ref PropertyBuilder propertyBuilder)
		{
			propertyBuilder = typeBuilder.DefineProperty(
				property.Name, property.Attributes, property.PropertyType, null);
		}

		private static void GenerateMethodImplementation(
			TypeBuilder typeBuilder, MethodInfo method, 
			PropertyBuilder[] properties, FieldBuilder handlerField, Type inter)
		{
			ParameterInfo[] parameterInfo = method.GetParameters();

			System.Type[] parameters = new System.Type[parameterInfo.Length];
			
			for(int i=0; i<parameterInfo.Length; i++)
				parameters[i] = parameterInfo[i].ParameterType;

			MethodAttributes atts = MethodAttributes.Public|MethodAttributes.Virtual;

			if(method.Name.StartsWith("set_") || method.Name.StartsWith("get_"))
				atts = MethodAttributes.Public|MethodAttributes.SpecialName|MethodAttributes.Virtual;

			MethodBuilder methodBuilder = 
				typeBuilder.DefineMethod(method.Name, atts, CallingConventions.Standard, 
				method.ReturnType, parameters);

			if(method.Name.StartsWith("set_") || method.Name.StartsWith("get_"))
			{
				foreach(PropertyBuilder property in properties)
				{
					if(property == null) break;

					if(!property.Name.Equals(method.Name.Substring(4))) continue;

					if(methodBuilder.Name.StartsWith("set_"))
					{
						property.SetSetMethod(methodBuilder);
						break;
					}
					else 
					{
						property.SetGetMethod(methodBuilder);
						break;
					}
				}
			}

			WriteILForMethod(methodBuilder, parameters, handlerField, method);
		}

		private static void WriteILForMethod(MethodBuilder builder, 
			System.Type[] parameters, FieldBuilder handlerField, MethodInfo method)
		{
			int arrayPositionInStack = 1;

			ILGenerator ilGenerator = builder.GetILGenerator();

			ilGenerator.DeclareLocal(typeof(MethodBase));

			if(builder.ReturnType != typeof(void))
			{
				ilGenerator.DeclareLocal(builder.ReturnType);
				arrayPositionInStack = 2;
			}

			ilGenerator.DeclareLocal(typeof(object[]));

			ilGenerator.Emit(OpCodes.Ldtoken, method);
			ilGenerator.Emit(OpCodes.Call, typeof(MethodBase).GetMethod("GetMethodFromHandle", new Type[]{typeof(RuntimeMethodHandle)}));
			ilGenerator.Emit(OpCodes.Stloc_0);
			ilGenerator.Emit(OpCodes.Ldarg_0);
			ilGenerator.Emit(OpCodes.Ldfld, handlerField);
			ilGenerator.Emit(OpCodes.Ldloc_0);
			ilGenerator.Emit(OpCodes.Ldc_I4, parameters.Length);
			ilGenerator.Emit(OpCodes.Newarr, typeof(object));

			if(parameters.Length != 0)
			{
				ilGenerator.Emit(OpCodes.Stloc, arrayPositionInStack);
				ilGenerator.Emit(OpCodes.Ldloc, arrayPositionInStack);
			}

			for(int c=0; c<parameters.Length; c++)
			{
				ilGenerator.Emit(OpCodes.Ldc_I4, c);
				ilGenerator.Emit(OpCodes.Ldarg, c+1);

				if(parameters[c].IsValueType)
				{
					ilGenerator.Emit(OpCodes.Box, parameters[c].UnderlyingSystemType);
				}

				ilGenerator.Emit(OpCodes.Stelem_Ref);
				ilGenerator.Emit(OpCodes.Ldloc, arrayPositionInStack);
			}

			ilGenerator.Emit(OpCodes.Callvirt, handlerField.FieldType.GetMethod("Invoke"));

			if(builder.ReturnType != typeof(void))
			{
				if(builder.ReturnType.IsValueType)
					ilGenerator.Emit(OpCodes.Unbox_Any, builder.ReturnType);
				else
					ilGenerator.Emit(OpCodes.Castclass, builder.ReturnType);

				ilGenerator.Emit(OpCodes.Stloc, 1);

				Label label = ilGenerator.DefineLabel();
				ilGenerator.Emit(OpCodes.Br_S, label);
				ilGenerator.MarkLabel(label);
				ilGenerator.Emit(OpCodes.Ldloc, 1);
			}
			else
			{
				ilGenerator.Emit(OpCodes.Pop);
			}

			ilGenerator.Emit(OpCodes.Ret);
		}

	}
}

namespace System.Runtime.CompilerServices
{
    [AttributeUsage(AttributeTargets.Assembly)]
    class IgnoresAccessChecksToAttribute : Attribute
    {
        public IgnoresAccessChecksToAttribute(string assemblyName)
        {
        }
    }
}
