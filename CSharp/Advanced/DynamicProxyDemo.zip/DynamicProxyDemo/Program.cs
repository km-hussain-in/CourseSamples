﻿using Proxying;
using System;
using System.Reflection;

interface IArrive
{
	string Meet(string name, bool formal);
}

interface IDepart
{
	string Leave(string name);
}

interface IPlayer
{
	void Play(int count);
}

class Greeter : IArrive, IDepart
{
	public Greeter()
	{
		Console.WriteLine("Greeter activated.");
	}

	public string Meet(string name, bool formal)
	{
		if(formal)
			return "Hello " + name;
		return "Hi " + name;
	}	

	string IDepart.Leave(string name)
	{
		return "Bye " + name;
	}
}

struct DoorBell : IPlayer
{
	public void Play(int count)
	{
		Console.WriteLine("Ding Dong{0}", new string('!', count));
	}
}

class ActivateOnDemandProxy
{

	public static object Create(Type targetType)
	{
		var handler = delegate(MethodBase method, object[] arguments)
		{ 
			var targetObject = Activator.CreateInstance(targetType);
			return method.Invoke(targetObject, arguments);
		};

		return ProxyActivator.CreateInstance(handler, targetType.GetInterfaces());
	}	
}

class EchoProxyBuilder(object original)
{
	public object Invoke(MethodBase method, object[] args)
	{
		Console.WriteLine("Invoking {0}::{1} [{2}]", original.GetType().Name, method.Name, DateTime.Now);
		try
		{
			return method.Invoke(original, args);
		}
		finally
		{
			Console.WriteLine("Invoked  {0}::{1} [{2}]", original.GetType().Name, method.Name, DateTime.Now);
		}
	}

	public I Build<I>()
	{
		return ProxyActivator.CreateInstance<I>(this);
	}

}

class Program
{
	public static void Main(string[] args)
	{
		var g = (IArrive)ActivateOnDemandProxy.Create(typeof(Greeter));
		//Console.WriteLine(g.GetType().AssemblyQualifiedName);
		foreach(string person in args)
			Console.WriteLine(g.Meet(person, true));
		Console.WriteLine((g as IDepart).Leave("Everybody"));
		Console.WriteLine("--------------------------------------");
		var p = new EchoProxyBuilder(new DoorBell()).Build<IPlayer>();
		p.Play(3);
	}
}


