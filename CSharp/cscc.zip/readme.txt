Open terminal and copy dotnet-csc script into $HOME/.dotnet/tools which must be in the path

Compile a library:
     dotnet csc MyLib.cs -t:library 
this will output MyLib.dll (can be changed with -out:)

Compile a program:
     dotnet csc MyApp.cs -r:MyLib.dll
 this will output MyApp.dll and MyApp.runtimeconfig.json

Run the program:
     dotnet MyApp.dll
