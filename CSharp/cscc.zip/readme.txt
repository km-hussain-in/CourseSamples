1. Download and install latest .NET SDK from https://dotnet.microsoft.com/en-us/download

2. Install script as dotnet tool

     Windows: copy dotnet-csc.cmd into %USERPROFILE%\.dotnet\tools create this folder if it does not exist and add it to the system path

     Linux: chmod u+x dotnet-csc and copy dotnet-csc into $HOME\.dotnet\tools create this folder if it does not exist and add it to the $PATH

3. Use dotnet csc to compile a

  Library:
     dotnet csc MyLib.cs -t:library 
this will output MyLib.dll (can be changed with -out:)
 
  Program:
     dotnet csc MyApp.cs -r:MyLib.dll 
 this will output MyApp.dll and MyApp.runtimeconfig.json

4. Run the program:
     dotnet MyApp.dll
