namespace Banking
{
	public class InsufficientFundsException : System.ApplicationException {}
}

