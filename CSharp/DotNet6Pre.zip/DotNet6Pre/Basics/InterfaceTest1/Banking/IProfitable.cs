namespace Banking
{
	public interface IProfitable
	{
		decimal GetInterest(int months);
	}
}

