namespace Banking
{
	public interface IChargeable
	{
		bool Withdraw(decimal rate);
	}
}

