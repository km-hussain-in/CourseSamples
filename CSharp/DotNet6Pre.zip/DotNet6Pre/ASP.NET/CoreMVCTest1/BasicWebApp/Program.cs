var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddSingleton<Dictionary<string, int>>();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
app.UseRouting();
app.UseEndpoints(endpoints =>
{
	endpoints.MapControllerRoute("default", "{action}/{id}", new {controller = "Greeter", id = "Visitor"});
});
app.Run();

