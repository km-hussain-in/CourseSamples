namespace BasicWebApp
{
    public class Greeting
    {
		public static async Task Generate(HttpContext context)
		{
			var visitor = context.GetRouteValue("person");
			await context.Response.WriteAsync
			($@"
				<html>
					<head><title>BasicWebApp</title></head>
					<body>
						<h1>Welcome {visitor}</h1>
						<b>Current Time: </b>{DateTime.Now}
						<p>
							<b>Number of Greetings: </b>{context.Items["hits"]}
						</p>
					</body>
				</html>
			");
		}
	}
}

