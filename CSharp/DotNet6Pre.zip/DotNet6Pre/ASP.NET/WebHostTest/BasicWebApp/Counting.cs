namespace BasicWebApp
{

	public class Counting
	{
		Dictionary<string, int> _counters;
		RequestDelegate _next;

		public Counting(Dictionary<string, int> counters, RequestDelegate next) => (_counters, _next) = (counters, next);

		public async Task Invoke(HttpContext context)
		{
			string id = context.Request.Path.Value;
			lock(_counters)
			{
				_counters.TryGetValue(id, out int count);
				context.Items["hits"] = _counters[id] = ++count;
			}
			await _next.Invoke(context);
		}

	}

}

