using BasicWebApp;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<Dictionary<string, int>>();
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseRouting();
//app.MapGet("/", () => "Hello World!");

app.UseMiddleware<Counting>();
app.UseEndpoints(endpoints =>
{
	endpoints.MapGet("/Greet/{person=Visitor}", Greeting.Generate);
});

app.Run();
